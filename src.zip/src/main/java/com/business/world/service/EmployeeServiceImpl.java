package com.business.world.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.business.world.dao.IDatabaseAccess;
import com.business.world.entity.EmployeeEntity;
import com.business.world.util.ExcelReader;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private IDatabaseAccess daoAccess;

	@Override
	public Integer createEmployee(String id, EmployeeEntity emp)
			throws Exception {
		return daoAccess.createEmployee(id, emp);
	}

	@Override
	public List<EmployeeEntity> getAllEmployees() {
		List<EmployeeEntity> empList = daoAccess.getAllEmployees();
		return empList;
	}

	public List<EmployeeEntity> getEmployeeById(String id) {
		List<EmployeeEntity> empObj = daoAccess.getEmployeeById(id);
		return empObj;
	}

	@Override
	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp)
			throws Exception {
		return daoAccess.updateEmployee(id, emp);
	}

	@Override
	public void deleteEmployee(String id) throws Exception {
		daoAccess.deleteEmployee(id);

	}

	@Override
	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception {

		return daoAccess.createEmployee(empList);
	}

	@Override
	public Integer insertFromExcel(String id) throws Exception {
		Integer searchedId = 0;

		List<EmployeeEntity> emp = ExcelReader.excelToEntity();
		
		List<EmployeeEntity> singleEmpList = emp.stream()
				.filter(x -> x.getId().equalsIgnoreCase(id))
				.collect(Collectors.toList());
		System.out.println("--------singleEmpList----" + singleEmpList);
		EmployeeEntity singleEmp= singleEmpList.get(0);
		
		 /* for (EmployeeEntity singleEmp : emp) {
		  System.out.println("Looking for the record in excel"); String
		  tempEmployeeId = singleEmp.getId();
		 
		  if (tempEmployeeId == id) { System.out.println("Id got matched");
		  
		  searchedId = daoAccess .createEmployee(tempEmployeeId, singleEmp);
		  break;
		  } else
		  { System.out
		  .println("------------ record doesnot exists in excel------------");
		  searchedId =-1; }
		  
		  }*/
		 

		if (singleEmp != null) {
			System.out.println("Id got matched");

			searchedId = daoAccess.createEmployee(singleEmp.getId(), singleEmp);
			return searchedId;
		} else {
			System.out
					.println("------------ record doesnot exists in excel------------");
			return -1;
		}
//return searchedId;
	}

}
