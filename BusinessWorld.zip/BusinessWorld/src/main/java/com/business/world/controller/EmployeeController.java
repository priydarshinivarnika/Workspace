package com.business.world.controller;

import java.sql.SQLException;

import org.hibernate.exception.ConstraintViolationException;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.business.world.entity.EmployeeEntity;
import com.business.world.service.IEmployeeService;
import com.business.world.util.JsonReader;
import com.google.gson.stream.MalformedJsonException;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService empService;

	@GetMapping("/hello")
	public String hello() {
		return "Welcome to Spring Boot Project";
	}

	// ---------CREATE--------------
	// ------------create record from json---------
	@PostMapping(value = "/employee")
	@ResponseBody
	public String insertRecord(@RequestBody String json) throws SQLException {
		System.out.println("------------Inside InsertRecord Method----------");
		EmployeeEntity emp = null;
		String responseMsg = "";
		try {
			emp = JsonReader.jsonToEmployee(json);
			
			//code to check for the record in excel 
			responseMsg = ExcelWriter.insertIntoExcel(emp);
			if (emp.getEmployeeId() != null || emp.getFirstName() != null) {
				responseMsg = empService.createEmployee(emp);
			} else {
				System.out
						.println("------------ Record Cannot be Empty------------");
				throw new MalformedJsonException(
						"Record is not in the correct format");
			}
		} catch (ConstraintViolationException e) {
			e.printStackTrace();
			responseMsg = "Record already exist in Database for id [ "
					+ emp.getEmployeeId() + " ]";
		} catch (Exception e) {
			Throwable t = e.getCause();
			while ((t != null) && !(t instanceof PSQLException)) {
				t = t.getCause();
			}
			if (t instanceof PSQLException) {
				// Here you're sure you have a PSQLException, you can handle it
				e.printStackTrace();
				responseMsg = "Duplicate key value violates unique constraint employee_pkey ["
						+ emp.getEmployeeId() + " ]";
			} else {
				responseMsg = "Unwanted Exception Occured, Please provide not null fields";
			}
		}
		return responseMsg;
	}

	/*// ---------create record from excel based on the id---------------
	@PostMapping(value = "/excel/{id}")
	@ResponseBody
	public String insertExcelToDbById(@PathVariable("id") String id)
			throws Exception {
		System.out
				.println("------------String insertExcelToDbById(String id)----------");
		String responseString = " ";
		Integer insertedEmployee = 0;
		try {
			insertedEmployee = empService.insertFromExcel(id);

			if (insertedEmployee != -1) {

				responseString = "Employees Inserted Successfully into db with the id-[ "
						+ id + "] from excel";
			}

		} catch (Exception e) {
			e.printStackTrace();
			responseString = e.getMessage();
		}
		return responseString;
	}

	// ---------------create records from excel---------------
	@PostMapping(value = "/excel")
	@ResponseBody
	public String insertRecordFromExcel() {
		System.out.println("------------insertRecordFromExcel----------");
		List<EmployeeEntity> emp = ExcelReader.excelToEntity();

		System.out.println(emp);
		List<Integer> insertedElements = new LinkedList<Integer>();
		try {

			insertedElements = empService.createEmployee(emp);

		} catch (Exception e) {
			e.printStackTrace();
			return "Error while adding list of employees";
		}
		return "Total Employees Inserted Successfully are ["
				+ insertedElements.size() + "]";
	}

	// ---------READ---------------
	// ---------read record from database using id---------------
	@GetMapping(value = "/employee/{id}")
	@ResponseBody
	public String getRecordById(@PathVariable("id") String id) {
		System.out.println("-----------Inside getRecord By Id------------");
		List<String> emp = null;
		String responseType = "";

		try {

			List<EmployeeEntity> fetchedEmpExcelList = empService
					.fetchFromExcel(id);
			List<EmployeeEntity> searchedEmpList;
			if (fetchedEmpExcelList.isEmpty()) {
				System.out.println("Record does not exists for id-[" + id
						+ "] in excel");
				List<EmployeeEntity> fetchedEmpDBList = empService
						.getEmployeeById(id);
				emp = JsonReader.employeeToJson(fetchedEmpDBList);

				System.out.println("Found list from database : " + emp);
				responseType = "Fetched from database :";
			} else {
				List<EmployeeEntity> singleEmp = fetchedEmpExcelList;
				emp = JsonReader.employeeToJson(singleEmp);
				System.out.println("Found the list in excel:"
						+ fetchedEmpExcelList);
				responseType = "Fetched from excel:";
			}

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return responseType + "\n" + emp.get(0);
	}

	// -------read all employees from database----------
	@GetMapping(value = "/employee", produces = "application/json")
	@ResponseBody
	public List<String> getRecord() {
		System.out.println("-----------Inside getRecord------------");
		List<EmployeeEntity> empList = empService.getAllEmployees();
		List<String> emp = JsonReader.employeeToJson(empList);
		return emp;
	}

	// ---------UPDATE---------------
	// -------update record in database using id----------------
	@PutMapping(value = "/employee/{id}", produces = "application/json")
	@ResponseBody
	public String updateRecord(@PathVariable("id") String id,
			@RequestBody String json) {
		System.out.println("---------Inside update Record-----------");
		EmployeeEntity emp = JsonReader.jsonToEmployee(json);

		System.out.println(emp);
		EmployeeEntity updatedEntity = null;
		try {
			updatedEntity = empService.updateEmployee(id, emp);
		} catch (Exception e) {
			e.printStackTrace();
			return "Employee -" + emp.getId()
					+ "- could not be found in our records";
		}
		return new Gson().toJson(updatedEntity);
	}

	// -------DELETE---------
	// --------delete record from database using id----------------
	@DeleteMapping(value = "/employee/{id}")
	public String deleteRecord(@PathVariable("id") String id) throws Exception {
		System.out.println("---------Inside delete Record by id-----------");
		String responseString = " ";
		try {
			responseString = empService.deleteEmployee(id);
		} catch (Exception e) {
			e.printStackTrace();
			responseString = e.getMessage();
		}

		return responseString;

	}

	@PutMapping(value = "/excel")
	@ResponseBody
	public String updateRecordFromExcel() {
		System.out.println("------------insertRecordFromExcel----------");
		List<EmployeeEntity> emp = ExcelReader.excelToEntity();

		System.out.println(emp);
		// String tempId = ((EmployeeEntity) emp).getId();
		List<Integer> insertedElements = new LinkedList<Integer>();
		try {

			insertedElements = empService.createEmployee(emp);

		} catch (Exception e) {
			e.printStackTrace();
			return "Error while adding list of employees";
		}
		return "Total Employees Inserted Successfully are ["
				+ insertedElements.size() + "]";

	}*/

}
