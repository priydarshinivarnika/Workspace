package com.business.world.controller;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.exception.ConstraintViolationException;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.business.world.entity.EmployeeEntity;
import com.business.world.service.IEmployeeService;
import com.business.world.util.JsonReader;
import com.google.gson.stream.MalformedJsonException;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService empService;

	@GetMapping("/hello")
	public String hello() {
		return "Welcome to Spring Boot Project";
	}

	// ---------CREATE--------------
	// ------------create record from json---------
	@PostMapping(value = "/employee")
	@ResponseBody
	public String insertRecord(@RequestBody String json) throws SQLException {
		System.out.println("------------Inside InsertRecord Method----------");
		EmployeeEntity emp = null;
		String responseMsg = "";
		try {
			emp = JsonReader.jsonToEmployee(json);

			// code to check for the record in excel
			// responseMsg = ExcelWriter.insertIntoExcel(emp);
			if (emp.getEmployeeId() != null) {
				responseMsg = empService.createEmployee(emp);
			} else {
				System.out
						.println("------------ Record Cannot be Empty------------");
				throw new MalformedJsonException(
						"Record is not in the correct format");
			}
		} catch (ConstraintViolationException e) {
			e.printStackTrace();
			responseMsg = "Record already exist in Database for id [ "
					+ emp.getEmployeeId() + " ]";
		} catch (Exception e) {
			Throwable t = e.getCause();
			while ((t != null) && !(t instanceof PSQLException)) {
				t = t.getCause();
			}
			if (t instanceof PSQLException) {
				// Here you're sure you have a PSQLException, you can handle it
				e.printStackTrace();
				responseMsg = "Duplicate key value violates unique constraint employee_pkey ["
						+ emp.getEmployeeId() + " ]";
			} else {
				responseMsg = "Unwanted Exception Occured, Please provide not null fields";
			}
		}
		return responseMsg;
	}

	// ---------create record from excel based on the id---------------
	@PostMapping(value = "/excel/{employeeId}")
	@ResponseBody
	public String insertExcelToDbById(
			@PathVariable("employeeId") String employeeId) throws Exception {
		System.out
				.println("------------String insertExcelToDbById(String id)----------");
		String responseMsg = " ";
		String insertedEmployee;
		try {
			insertedEmployee = empService.insertFromExcel(employeeId);

			if (insertedEmployee != null) {

				responseMsg = "Employees Inserted Successfully into db with the employeeId-[ "
						+ employeeId + "] from excel";
			}

		} catch (Exception e) {
			e.printStackTrace();
			responseMsg = e.getMessage();
		}
		return responseMsg;
	}

	// ---------------create records from excel---------------
	@PostMapping(value = "/excel")
	@ResponseBody
	public String insertRecordFromExcel() {
		System.out.println("------------insertRecordFromExcel----------");
		String responseMsg = " ";
		List<EmployeeEntity> insertedEmployee = empService.insertAllFromExcel();

		System.out.println(insertedEmployee);
		List<Integer> insertedElements = new LinkedList<Integer>();
		try {

			insertedElements = empService.createEmployee(insertedEmployee);
			responseMsg = "Total Employees Inserted Successfully are ["
					+ insertedElements.size() + "]";

		} catch (Exception e) {
			e.printStackTrace();
			responseMsg = "Error while adding list of employees";

		}
		return responseMsg;
	}

	// ---------READ---------------
	// ---------read record from database using id---------------
	@GetMapping(value = "/employee/{employeeId}")
	@ResponseBody
	public String getRecordById(@PathVariable("employeeId") String employeeId) {
		System.out.println("-----------Inside getRecord By Id------------");
		List<String> emp = null;
		String responseMsg = "";

		try {

			List<EmployeeEntity> fetchedEmpExcelList = empService
					.fetchFromExcel(employeeId);
			if (fetchedEmpExcelList.isEmpty()) {
				System.out.println("Record does not exists for id-["
						+ employeeId + "] in excel");
				List<EmployeeEntity> fetchedEmpDBList = empService
						.getEmployeeById(employeeId);
				if (fetchedEmpDBList != null) {
					emp = JsonReader.employeeToJson(fetchedEmpDBList);
					System.out.println("Record found in database only: ");
					responseMsg = "Record found in database only: ";
				} else {
					responseMsg = "Record doesnot exist for id-[ " + employeeId
							+ " ] in Excel and Database";
				}

			} else {
				List<EmployeeEntity> singleEmp = fetchedEmpExcelList;
				emp = JsonReader.employeeToJson(singleEmp);
				System.out.println("Record found in Excel: "
						+ fetchedEmpExcelList);
				responseMsg = "Record found in Excel: ";
			}

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return responseMsg + "\n" + emp.get(0);
	}

	// -------read all employees from database----------
	@GetMapping(value = "/employee", produces = "application/json")
	@ResponseBody
	public List<String> getAllRecord() {
		System.out.println("-----------Inside getRecord------------");
		List<EmployeeEntity> empList = empService.getAllEmployees();
		List<String> emp = JsonReader.employeeToJson(empList);
		return emp;
	}

	// -------DELETE---------
	// --------delete record from database using id----------------
	@DeleteMapping(value = "/employee/{employeeId}")
	public String deleteRecord(@PathVariable("employeeId") String employeeId)
			throws Exception {
		System.out.println("---------Inside delete Record by id-----------");
		String responseMsg = " ";
		try {
			responseMsg = empService.deleteEmployee(employeeId);
		} catch (Exception e) {
			e.printStackTrace();
			responseMsg = e.getMessage();
		}

		return responseMsg;

	}

	// ---------UPDATE---------------
	// -------update record in database using id----------------
	@PutMapping(value = "/employee", produces = "application/json")
	@ResponseBody
	public String updateRecord(@RequestBody String json) throws Exception {
		System.out.println("---------Inside update Record-----------");
		EmployeeEntity emp = null;
		String responseMsg = "";

		try {
			emp = JsonReader.jsonToEmployee(json);
			if (emp.getEmployeeId() != null) {
				responseMsg = empService.updateEmployee(emp);
			} else {
				responseMsg = "Employee -[ " + emp.getEmployeeId()
						+ " ] could not be found in Database record";
			}

		} catch (NumberFormatException e) {
			e.printStackTrace();
			responseMsg = "Format Exception Pls check the type of fields";
		} catch (MalformedJsonException e) {
			e.printStackTrace();
			responseMsg = "Record can not be empty";
		}

		return responseMsg;

	}

	/*
	 * 
	 * @PutMapping(value = "/excel")
	 * 
	 * @ResponseBody public String updateRecordFromExcel() {
	 * System.out.println("------------insertRecordFromExcel----------");
	 * List<EmployeeEntity> emp = ExcelReader.excelToEntity();
	 * 
	 * System.out.println(emp); // String tempId = ((EmployeeEntity)
	 * emp).getId(); List<Integer> insertedElements = new LinkedList<Integer>();
	 * try {
	 * 
	 * insertedElements = empService.createEmployee(emp);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); return
	 * "Error while adding list of employees"; } return
	 * "Total Employees Inserted Successfully are [" + insertedElements.size() +
	 * "]";
	 * 
	 * }
	 */

}
