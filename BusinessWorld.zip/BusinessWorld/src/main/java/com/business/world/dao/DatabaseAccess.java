package com.business.world.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.business.world.entity.EmployeeEntity;


@Repository
@Transactional
public class DatabaseAccess implements IDatabaseAccess {

	Map<Integer, EmployeeEntity> empData = new HashMap<Integer, EmployeeEntity>();
	
	// Method To Find Particular Record In The Database Table
	public static EmployeeEntity findRecordById(String id) {
		EmployeeEntity findEmpObj = null;

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		findEmpObj = (EmployeeEntity) session.load(EmployeeEntity.class, id);
		session.getTransaction().commit();
		return findEmpObj;

	}

	// ---------Crud operation----

	public String createEmployee(EmployeeEntity emp) {
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		String message;
		session.save(emp);
		message = "Employee with id [ " + emp.getEmployeeId()
				+ " ] Inserted Successfully in Database";
		session.getTransaction().commit();
		session.close();
		return message;
	}

	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception {
		System.out
				.println("Inside createEmployee(List<EmployeeEntity> empList)");
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		List<Integer> insertedEmployeeIdList = new ArrayList<Integer>();
		List<Integer> i;
		for (EmployeeEntity entity : empList) {
			System.out.println("Searching for employee " + entity);

			Object persistentInstance = session.get(EmployeeEntity.class,
					entity.getEmployeeId());

			if (persistentInstance == null) {
				System.out.println("Creating new employee.. [" + entity + "]");
				insertedEmployeeIdList.add((Integer) session.save(entity));
				
				

			} else {
				System.out
						.println("------------ record already exists moving to next record ------------");

			}
		}

		session.getTransaction().commit();
		session.close();
		System.out.println("Id of inserted elements " + insertedEmployeeIdList);
		return insertedEmployeeIdList;
	}
	
	

	public List<EmployeeEntity> getEmployeeById(String employeeId) {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		Query query = session
				.createQuery("select e from EmployeeEntity e where e.id =:arg");
		query.setParameter("arg", employeeId);
		List result = query.getResultList();
		System.out.println("Found employess : " + result);
		session.getTransaction().commit();
		session.close();
		return result;
	}
	@SuppressWarnings("unchecked")
	public List<EmployeeEntity> getAllEmployees() {
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		List<EmployeeEntity> fetchEmp = new LinkedList<EmployeeEntity>();
		fetchEmp = session.createQuery("from EmployeeEntity").list();
		System.out.println("Found list of employess : " + fetchEmp);
		return fetchEmp;
	}

	public String deleteEmployee(String employeeId) throws Exception {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		System.out
				.println("------------ Inside String deleteEmployee(String employeeId) Method ------------");
		String message = "";

		Object persistentInstance = session.get(EmployeeEntity.class,
				employeeId);
		if (persistentInstance != null) {
			session.delete(persistentInstance);
			message = "Employee [" + employeeId
					+ "] is deleted from Database";
		} else {
			System.out
					.println("------Employee to be deleted does not exist in db---- ");
			session.close();
			throw new Exception("Cannot find any record with ID-[ "
					+ employeeId + " ] in Database");
		}
		session.getTransaction().commit();
		session.close();
		return message;

	}

	public String updateEmployee(EmployeeEntity emp) throws Exception {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		System.out.println("------------ Inside updateEmployee ------------");

		String message = "";

		session.update(emp);
		message = "Employee with id [ " + emp.getEmployeeId()
				+ " ] Updated Successfully in Database";

		session.getTransaction().commit();
		session.close();
		return message;
	}

	

}