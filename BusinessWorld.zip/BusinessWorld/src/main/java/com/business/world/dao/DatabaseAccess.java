package com.business.world.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;
import org.postgresql.util.PSQLException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.business.world.entity.EmployeeEntity;


@Repository
@Transactional
public class DatabaseAccess implements IDatabaseAccess {

	Map<Integer, EmployeeEntity> empData = new HashMap<Integer, EmployeeEntity>();
	private static List<EmployeeEntity> emps = new ArrayList<EmployeeEntity>(10);

	// Method To Find Particular Record In The Database Table
	public static EmployeeEntity findRecordById(String id) {
		EmployeeEntity findEmpObj = null;

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		findEmpObj = (EmployeeEntity) session.load(EmployeeEntity.class, id);
		session.getTransaction().commit();
		return findEmpObj;

	}

	// ---------Crud operation----

	public String createEmployee(EmployeeEntity emp) {
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		String message;
		session.save(emp);
		message = "Employee with id [ " + emp.getEmployeeId()
				+ " ] Inserted Successfully in Database";
		session.getTransaction().commit();
		session.close();
		return message;
	}

	/*public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception {
		System.out
				.println("Inside createEmployee(List<EmployeeEntity> empList)");
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		List<Integer> insertedEmployeeIdList = new ArrayList<Integer>();
		for (EmployeeEntity entity : empList) {
			System.out.println("Searching for employee " + entity);
			List employeeList = getEmployeeById(entity.getId());

			if (employeeList == null || employeeList.isEmpty()) {
				System.out.println("Creating new employee.. [" + entity + "]");
				insertedEmployeeIdList.add((Integer) session.save(entity));

			} else {
				System.out
						.println("------------ record already exists moving to next record ------------");

			}
		}

		session.getTransaction().commit();
		session.close();
		System.out.println("Id of inserted elements " + insertedEmployeeIdList);
		return insertedEmployeeIdList;
	}

	@SuppressWarnings("unchecked")
	public List<EmployeeEntity> getAllEmployees() {
		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		List<EmployeeEntity> fetchEmp = new LinkedList<EmployeeEntity>();
		fetchEmp = session.createQuery("from EmployeeEntity").list();
		System.out.println("Found list of employess : " + fetchEmp);
		return fetchEmp;
	}
*/
	public List<EmployeeEntity> getEmployeeById(String id) {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();

		Query query = session
				.createQuery("select e from EmployeeEntity e where e.id =:arg");
		query.setParameter("arg", id);
		List result = query.getResultList();
		System.out.println("Found employess : " + result);
		session.getTransaction().commit();
		session.close();
		return result;
	}

	/*public EmployeeEntity updateEmployee(String id, EmployeeEntity emp)
			throws Exception {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		System.out.println("------------ Inside updateEmployee ------------");
		// Select the employee by id

		// If found update
		EmployeeEntity employee = getEmployeeById(id).get(0);
		EmployeeEntity mergedEntity = null;
		if (employee != null) {

			emp.setEmployeeId(employee.getEmployeeId());
			emp.setAddress(employee.getAddress());
			mergedEntity = (EmployeeEntity) session.merge(emp);

		} else {
			System.out.println("------------ no record found ------------");
			session.close();
			throw new Exception("Cannot find any records by [" + id + "]");
		}
		session.getTransaction().commit();
		session.close();
		return mergedEntity;
	}

	public String deleteEmployee(String id) throws Exception {

		Session session = new HibernateUtil().getSessionFactory().openSession();
		session.beginTransaction();
		System.out.println("------------ Inside deleteEmployee ------------");
		String deletedEmployeeId = "";
		List<EmployeeEntity> deleteEmployee = getEmployeeById(id);
		if (deleteEmployee.isEmpty()) {
			System.out
					.println("------Employee to be deleted does not exist in db---- ");
			session.close();
			throw new Exception("Cannot find any record by this ID [" + id
					+ "] in Database");
		} else {
			session.delete(deleteEmployee.get(0));
			deletedEmployeeId = "Employee [" + id
					+ "] is deleted from Database";

		}
		session.getTransaction().commit();
		session.close();
		return deletedEmployeeId;
	}*/

}