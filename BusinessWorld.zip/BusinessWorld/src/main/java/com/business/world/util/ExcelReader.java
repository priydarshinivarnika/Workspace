package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class ExcelReader {

	public static List<EmployeeEntity> excelToEntity() {
		EmployeeEntity entityList = null;
		ArrayList<EmployeeEntity> employeeList = new ArrayList<EmployeeEntity>();
		try {
			FileInputStream file = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));

			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// I've Header and I'm ignoring header for that I've +1 in loop
			for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
				EmployeeEntity e = new EmployeeEntity();
				AddressEntity a = new AddressEntity();
				Row ro = sheet.getRow(i);
				for (int j = ro.getFirstCellNum(); j <= ro.getLastCellNum(); j++) {
					Cell ce = ro.getCell(j);
					if (j == 0) {
						((EmployeeEntity) e).setEmployeeId(ce
								.getStringCellValue());

					}
					if (j == 1) {
						((EmployeeEntity) e).setFirstName(ce
								.getStringCellValue());
					}

					if (j == 2) {
						((EmployeeEntity) e).setLastName(ce
								.getStringCellValue());
					}

					if (j == 3) {
						((EmployeeEntity) e).setSalary((int) ce
								.getNumericCellValue());
					}
					if (j == 4) {
						((AddressEntity) a)
								.setCityName(ce.getStringCellValue());
					}
					if (j == 5) {
						((AddressEntity) a).setTelephoneNumber((long) ce
								.getNumericCellValue());
					}
					if (j == 6) {
						((AddressEntity) a).setZipCode((int) ce
								.getNumericCellValue());
					}

					if (j == 7) {
						((AddressEntity) a).setHouseNumber((int) ce
								.getNumericCellValue());
					}
					if (j == 8) {
						((AddressEntity) a).setStreetName(ce
								.getStringCellValue());
					}
					if (j == 9) {
						((AddressEntity) a).setAddressType(ce
								.getStringCellValue());
					}
					if (j == 10) {
						((AddressEntity) a).setStreetType(ce
								.getStringCellValue());
					}

				}
				e.setAddress(a);
				employeeList.add(e);

				file.close();
			}
			
			//----Reads all the data in excel---------
			/*for (EmployeeEntity emp : employeeList) {
				System.out.println("ID:" + emp.getEmployeeId() + " firstName:"
						+ emp.getFirstName() + " lastName:" + emp.getLastName()
						+ " salary:" + emp.getSalary()
						+ emp.getAddress().toString() + "\n");
				entityList = emp;
			}*/

		} catch (Exception e) {
			System.out.println("Incorrect datatype");
			e.printStackTrace();
		}
		return employeeList;
	}

}
