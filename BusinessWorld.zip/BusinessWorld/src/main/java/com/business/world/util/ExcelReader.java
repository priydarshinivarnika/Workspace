package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class ExcelReader {

	public static List<EmployeeEntity> excelToEntity(String employeeId) {
		EmployeeEntity entityList = null;
		ArrayList<EmployeeEntity> employeeList = new ArrayList<EmployeeEntity>();
		try {
			FileInputStream file = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));

			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// I've Header and I'm ignoring header for that I've +1 in loop
			for (int i = sheet.getFirstRowNum() + 1; i <= sheet.getLastRowNum(); i++) {
				Row ro = sheet.getRow(i);

				int j = ro.getFirstCellNum();
				if (ro.getCell(j).getStringCellValue().equals(employeeId)) {
					EmployeeEntity e = new EmployeeEntity();
					AddressEntity a = new AddressEntity();
					Cell ce = ro.getCell(j++);
					e.setEmployeeId(ce.getStringCellValue());

					ce = ro.getCell(j++);
					e.setFirstName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					e.setLastName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					e.setSalary((int) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setAddressType(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setCityName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setHouseNumber((int) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setStreetName(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setStreetType(ce.getStringCellValue());
					ce = ro.getCell(j++);
					a.setTelephoneNumber((long) ce.getNumericCellValue());
					ce = ro.getCell(j++);
					a.setZipCode((int) ce.getNumericCellValue());
					
					e.setAddress(a);
					employeeList.add(e);
				}
				else {
					System.out.println("Record doesnot exist in excel for id-[ "+ employeeId+ " ]");
				}
				
				
				
				/*for (int j = ro.getFirstCellNum(); j <= ro.getLastCellNum(); j++) {
					Cell ce = ro.getCell(j);

					((EmployeeEntity) e).setEmployeeId(ce.getStringCellValue());
					if (e.getEmployeeId().equals(employeeId)) {
						j = 1;
						
					} else {
						System.out.println("Record doesnot exist in excel");

					}

				}
				e.setAddress(a);
				employeeList.add(e);*/

				file.close();
			}

			// ----Reads all the data in excel---------
			/*
			 * for (EmployeeEntity emp : employeeList) {
			 * System.out.println("ID:" + emp.getEmployeeId() + " firstName:" +
			 * emp.getFirstName() + " lastName:" + emp.getLastName() +
			 * " salary:" + emp.getSalary() + emp.getAddress().toString() +
			 * "\n"); entityList = emp; }
			 */

		} catch (Exception e) {
			System.out.println("Incorrect Datatype for the field");
			e.printStackTrace();
		}
		return employeeList;
	}

}
