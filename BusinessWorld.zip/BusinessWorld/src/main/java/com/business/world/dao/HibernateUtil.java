package com.business.world.dao;

import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private SessionFactory sessionFactory;

	private void initSession() {
		try {
			Configuration config = new Configuration();
			sessionFactory = config.configure().buildSessionFactory();
		} catch (Throwable th) {
			System.err.println("SessionFactory creation failed" + th);
			throw new ExceptionInInitializerError(th);
		}
	}

	public SessionFactory getSessionFactory() {
		if (sessionFactory != null) {
			return sessionFactory;
		} else {
			initSession();
			return getSessionFactory();
		}
	}

	public void shutdown() {
		getSessionFactory().close();
	}
}
