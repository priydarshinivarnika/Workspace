package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.EmployeeEntity;

public class ExcelWriter {

	/*public static String insertIntoExcel(List<EmployeeEntity> empList) {
		//String excelFilePath = "src/main/resources/EmployeeList.xlsx";
		String excelResponse;
		try {
			FileInputStream inputStream = new FileInputStream(new File(
					"src/main/resources/EmployeeList.xlsx"));
			Workbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();
for(EmployeeEntity emp : empList){
	

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;
			Cell cell = row.createCell(columnCount);
			cell.setCellValue(rowCount);
			for (Object field : emp) {
				cell = row.createCell(++columnCount);
				if (field instanceof String) {
					cell.setCellValue((String) field);
				} else if (field instanceof Integer) {
					cell.setCellValue((Integer) field);
				}
			}
}
			inputStream.close();
			FileOutputStream outputStream = new FileOutputStream("src/main/resources/EmployeeList.xlsx");

			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			excelResponse = "Record inserted successfully in Excel.";
		} catch (Exception e) {
			e.printStackTrace();
			excelResponse = "Record already Exist in excel";

		}
		return excelResponse;
	}*/

}
