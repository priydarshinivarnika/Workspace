package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.business.world.entity.EmployeeEntity;

public class ExcelWriter {

	public String insertIntoExcel(List<EmployeeEntity> empList) {
		String excelFilePath = "/Users/vxp142/LunaWorkspace/BusinessWorld/EmployeeList.xlsx";
		String excelResponse;
		try {
			FileInputStream inputStream = new FileInputStream(new File(
					excelFilePath));
			Workbook workbook = new XSSFWorkbook();
			XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();

			Row row = sheet.createRow(++rowCount);
			int columnCount = 0;
			Cell cell = row.createCell(columnCount);
			cell.setCellValue(rowCount);
			for (Object field : empList) {
				cell = row.createCell(++columnCount);
				if (field instanceof String) {
					cell.setCellValue((String) field);
				} else if (field instanceof Integer) {
					cell.setCellValue((Integer) field);
				}

			}

			inputStream.close();
			FileOutputStream outputStream = new FileOutputStream(excelFilePath);

			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			excelResponse = "Record inserted successfully in Excel.";
		} catch (Exception e) {
			e.printStackTrace();
			excelResponse = "Record already Exist in excel";

		}
		return excelResponse;
	}
}
