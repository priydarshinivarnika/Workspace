package com.business.world.service;

import java.util.List;

import org.postgresql.util.PSQLException;

import com.business.world.entity.EmployeeEntity;

public interface IEmployeeService {

	public String createEmployee(EmployeeEntity emp);

	/*public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception;

	public List<EmployeeEntity> getAllEmployees();

	public List<EmployeeEntity> getEmployeeById(String id);

	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp)
			throws Exception;

	public String deleteEmployee(String id) throws Exception;

	public Integer insertFromExcel(String id) throws Exception;

	List<EmployeeEntity> fetchFromExcel(String id) throws Exception;*/
}
