package com.business.world.service;

import java.util.List;

import com.business.world.entity.EmployeeEntity;

public interface IEmployeeService {

	public String createEmployee(EmployeeEntity emp);

	public String insertFromExcel(String employeeId) throws Exception;

	/*public List<EmployeeEntity> insertAllFromExcel();*/

	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception;

	List<EmployeeEntity> fetchFromExcel(String employeeId) throws Exception;

	public List<EmployeeEntity> getEmployeeById(String employeeId);

	public List<EmployeeEntity> getAllEmployees();

	public String deleteEmployee(String employeeId) throws Exception;

	public String updateEmployee(EmployeeEntity emp) throws Exception;

}
