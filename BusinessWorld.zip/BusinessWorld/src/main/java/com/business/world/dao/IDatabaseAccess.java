package com.business.world.dao;

import java.util.List;

import org.postgresql.util.PSQLException;

import com.business.world.entity.EmployeeEntity;

public interface IDatabaseAccess {

	public String createEmployee(EmployeeEntity emp);

	//public List<EmployeeEntity> getAllEmployees();

	/*public List<EmployeeEntity> getEmployeeById(String id);

	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp)
			throws Exception;

	public String deleteEmployee(String id) throws Exception;

	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception;*/
}
