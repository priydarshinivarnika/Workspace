package com.business.world.dao;

import java.util.List;

import org.postgresql.util.PSQLException;

import com.business.world.entity.EmployeeEntity;

public interface IDatabaseAccess {

	public String createEmployee(EmployeeEntity emp);

	public List<Integer> createEmployee(List<EmployeeEntity> empList)
			throws Exception;

	public List<EmployeeEntity> getEmployeeById(String employeeId);

	public List<EmployeeEntity> getAllEmployees();

	public String deleteEmployee(String employeeId) throws Exception;

	public String updateEmployee(EmployeeEntity emp)
	 throws Exception;
	 
}
