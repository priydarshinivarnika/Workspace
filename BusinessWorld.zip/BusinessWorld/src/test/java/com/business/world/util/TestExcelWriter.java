package com.business.world.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Test;


public class TestExcelWriter {

@Test
	public void testExcelWriter() {
        String excelFilePath = "src/test/resources/EmployeeList.xlsx";
         
        try {
            FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
            Workbook workbook = WorkbookFactory.create(inputStream);
 
            XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
 
            Object[][] bookData = {
                    {"The Passionate Programmer", "Chad Fowler", 16},
                    
            };
 
            int rowCount = ((org.apache.poi.ss.usermodel.Sheet) sheet).getLastRowNum();
 
            for (Object[] aBook : bookData) {
                Row row = ((org.apache.poi.ss.usermodel.Sheet) sheet).createRow(++rowCount);
 
                int columnCount = 0;
                 
                Cell cell = row.createCell(columnCount);
                cell.setCellValue(rowCount);
                 
                for (Object field : aBook) {
                    cell = row.createCell(++columnCount);
                    if (field instanceof String) {
                        cell.setCellValue((String) field);
                    } else if (field instanceof Integer) {
                        cell.setCellValue((Integer) field);
                    }
                }
 
            }
 
            inputStream.close();
 
            FileOutputStream outputStream = new FileOutputStream("EmployeeList.xlsx");
            workbook.write(outputStream);
            workbook.close();
            outputStream.close();
            System.out.println("EmployeeList.xlsx written successfully on disk within the project.");
             
        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
