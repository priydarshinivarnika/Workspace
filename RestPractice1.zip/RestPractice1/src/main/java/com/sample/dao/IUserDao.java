package com.sample.dao;

import com.sample.model.User;

public interface IUserDao {

	void saveUser(User user);
	void updateUser(User user);
	void deleteUser(User user);
}
