package com.sampleservlet;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	private String message = null;
	private String userName;
	private String password;
	private String directoryName =  "C:/Users/bxm205";
	private String fileName = "userDetails";

	public void init(){

	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException{

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Login Form</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form method='POST' >");
		out.println("<h1>User Login</h1>");
		out.println("<label>User Name :</label>");
		out.println("<input type='text' name='username' required='true'/>");
		out.println("</br>");
		out.println("</br>");
		out.println("<label>Password :</label>");
		out.println("<input type='password' name='password' required='true'/>");
		out.println("</br>");
		out.println("</br>");
		out.println("<input type='submit' name='Submit' />");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");


	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException{


		userName = req.getParameter("username");
		password = req.getParameter("password"); 

		String userData = userName + "," + password;

		File directory = new File(directoryName);

		File file = new File(directoryName + "/" + fileName);

		String line = null;

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Login Form</title>");
		out.println("</head>");
		out.println("<body>");

		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = new FileReader(file);

			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while((line = bufferedReader.readLine()) != null) {

				String[] userProfile = line.split(",");

				if(userProfile[0].equals(userName) && userProfile[1].equals(password)){
					message = "Welcome\t" + userName ;
					out.println(message);
					break;
				}
			}   
			bufferedReader.close();     
			if(message == null){
				out.println("User Name / Password is not matching...!!");
				out.println("</br>");
				out.println("<button><a href='login.html'>User Login</a></button>");
			}
			out.println("</br>");
			out.println("<button><a href='home.html'>Logout</a></button>");

			out.println("</body>");
			out.println("</html>");
		}
		catch(FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");                
		}
		catch(IOException ex) {
			System.out.println( "Error reading file '" + fileName + "'");                  
		}
	}

}
