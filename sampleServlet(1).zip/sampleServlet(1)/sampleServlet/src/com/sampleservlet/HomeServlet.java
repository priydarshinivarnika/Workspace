package com.sampleservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HomeServlet extends HttpServlet{
	
	
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException{
		res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Home Page</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>User Registeration</h1>");
        out.println("<button><a href='register.html'>User Registeration</a></button>");
        out.println("<button><a href='login.html'>User Login</a></button>");
        
        
        out.println("</body>");
        out.println("</html>");
		
	}

}

