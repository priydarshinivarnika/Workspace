package com.sampleservlet;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegistrationServlet extends HttpServlet{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;
	private String userName;
	private String password;
	private String directoryName = "C:/Users/bxm205";
	private String fileName = "userDetails";

	public void init() throws ServletException{

	}

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException{

		res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Registration Form</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<form method='POST' >");
        out.println("<h1>User Registeration</h1>");
        out.println("<label>User Name :</label>");
        out.println("<input type='text' name='username' required='true'/>");
        out.println("</br>");
        out.println("</br>");
        out.println("<label>Password :</label>");
        out.println("<input type='password' name='password' required='true'/>");
        out.println("</br>");
        out.println("</br>");
        out.println("<input type='submit' name='Submit' />");
        out.println("</form>");
        
        
        out.println("</body>");
        out.println("</html>");

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res){

		userName = req.getParameter("username");
		password = req.getParameter("password"); 

		String userDetails = userName + "," + password;

		File directory = new File(directoryName);

		if (! directory.exists()){
			directory.mkdir();
		}

		File file = new File(directoryName + "/" + fileName);
		try{
			
			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(), true);
			BufferedWriter bw = new BufferedWriter(fileWriter);
			bw.write(userDetails);
			bw.newLine();
			bw.close();
			
			res.setContentType("text/html");
	        PrintWriter out = res.getWriter();
	        out.println("<html>");
	        out.println("<head>");
	        out.println("<title>Registration Successfull</title>");
	        out.println("</head>");
	        out.println("<body>");
	        out.println("User Registered Successfully");
	        out.println("</br>");
	        out.println("<button><a href='login.html'>Login</a></button>");
	        out.println("</body>");
	        out.println("</html>");
			
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}

}
